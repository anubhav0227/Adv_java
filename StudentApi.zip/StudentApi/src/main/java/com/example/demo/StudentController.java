package com.example.demo;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping("/details")
public class StudentController {
	
	List<Student> student = new ArrayList<>();
	
	@GetMapping("/view")
	public List<Student> getDetails(){
		return student;
	}
	
	@PostMapping("/addStudent")
	public String addStudent(@RequestBody Student s) {
		student.add(s);
		return "ADDED SUCCESSFULLY";
	}
	
	@GetMapping("/{id}")
	public List<Student> getDetailsById(@PathVariable int id){
		List<Student> temp = new ArrayList<>();
		for(Student s1 : student) {
			if(s1.getId() == id) {
				temp.add(s1);
				return temp;
			}
		}
		return null;
	}
	
	@PutMapping("/{id}")
	public String updateDetails(@PathVariable int id, @RequestBody Student s) {
		for(Student s1 : student) {
			if(s1.getId() == id) {
				s1.setName(s.getName());
				s1.setEmail(s.getEmail());
				return "UPDATED SUCCESSFULLY";
			}
		}
		return "NOT FOUND";
	}
	
	@DeleteMapping("/{id}")
	public String deleteDetails(@PathVariable int id) {
		for(Student s1 : student) {
			if(s1.getId() == id) {
				student.remove(s1);
				return "DELETED SUCCESSFULLY";
			}
		}
		return "NOT FOUND";
	}

}
