package com.example.demo;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.demo.Books;

public interface BookRepository extends JpaRepository<Books, Long> {

}
