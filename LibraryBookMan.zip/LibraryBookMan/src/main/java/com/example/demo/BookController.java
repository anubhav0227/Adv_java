package com.example.demo;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class BookController {

	private final BookRepository bookRepo;
	
	public BookController(BookRepository bookRepo) {
		super();
		this.bookRepo = bookRepo;
	}
	
	@GetMapping("/")
	public String bookForm(Model model) {
		model.addAttribute("book" , new Books());
		return "addBook";
	}
	
	@PostMapping("/addBook")
	public String addBook(Books book, Model model) {
		bookRepo.save(book);
		model.addAttribute("booklist", bookRepo.findAll());
		return "viewBooks";
	}
	
	@GetMapping("/getId")
	public String getId(@RequestParam (required = false) Long bookId, Model model) {
		if(bookId == null) {
			model.addAttribute("error", "Please enter the Book Id");
			return "searchBook";
		}
		
		Books book = bookRepo.findById(bookId).orElse(null);
		model.addAttribute("book", book);
		return "searchBook";
	}
	
	
}
